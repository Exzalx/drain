const path = require("path");
module.exports = {
  mode: "production",
  entry: "./src/wc-entry.js",
  output: {
    filename: "wallet.bundle.js",
    path: path.resolve(__dirname, "public"),
    library: { name: "WC", type: "umd" }
  },
  resolve: {
    fallback: {
      stream: false, crypto: false,
      buffer: false, process: false,
      path: false, os: false, fs: false
    }
  }
};
